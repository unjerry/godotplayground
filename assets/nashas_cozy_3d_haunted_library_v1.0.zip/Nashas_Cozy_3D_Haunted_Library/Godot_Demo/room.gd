extends Node3D
# Generic room viewer for kit rooms. Everything room-specific comes from ../Room_Config.json
# (title, views, lamps, cutaway) and ../Asset_Manifest.json (model list). Do not edit per room.
var cfg: Dictionary
var model: Node3D
var camera: Camera3D
var target:=Vector3.ZERO
var yaw:=.6
var pitch:=.5
var distance:=15.0
var orbit:=true
var keyspeed:=4.0
var ui: CanvasLayer
var info: Label
var picker: OptionButton
var world: WorldEnvironment
var key: DirectionalLight3D
var fill: DirectionalLight3D
var sky_mat: ProceduralSkyMaterial
var ground: MeshInstance3D
var ground_y:=0.0
var lamps: Array[OmniLight3D]=[]
var night:=false
# Room_Config "mood" (optional multipliers, default 1): ambient / key / fill / lamp, lamp_range in metres. For dim moody rooms.
var mood: Dictionary={}
# Room_Config "light": "cozy" -> ana Cozy 3D serisinin isigi (gokyuzu ortam isigi, filmic, SSAO, yumusak guclu gunes, iki genis dolgu).
var cozy:=false
var key_day:=.32
var fill_day:=.15
var amb_day:=.40
var backdrop: Dictionary={}
func mk(k: String) -> float: return float(mood.get(k,1.0))
# mood renkleri (opsiyonel hex; yoksa eski renk): key_color, fill_color, lamp_color, lamp_colors (lamps ile ayni sira, null = lamp_color),
# sky_top / sky_horizon / ground_horizon / ground_bottom (cozy isikta ortam isigi gokyuzunden gelir: odanin genel tonu). Fortune Teller: mor los.
func mc(k: String, d: Color) -> Color: return Color(str(mood[k])) if mood.has(k) else d
# glTF textures loaded at runtime have no mipmaps: fine patterns flickered while the camera moved, so mipmaps are generated here.
var mip_cache: Dictionary={}
func mipped(t: Texture2D) -> Texture2D:
	if not t is ImageTexture: return t
	if mip_cache.has(t): return mip_cache[t]
	var img:=t.get_image()
	if img==null or img.has_mipmaps(): mip_cache[t]=t; return t
	if img.is_compressed(): img.decompress()
	img.generate_mipmaps()
	var n:=ImageTexture.create_from_image(img); mip_cache[t]=n; return n
var gallery:=false
var gallery_asset: Node3D
var original_transforms: Dictionary={}
var original_visibility: Dictionary={}
var entries: Array=[]
var views: Array=[]
var cut_names: Array=[]
var slides: Dictionary={}
var hinges: Dictionary={}
var doors_open:=false
var cutaway:=true
var fps_label: Label
var capture_dir:=""
var capture_path:=""
var frames:=0
var capture_index:=0
var total_triangles:=0
var DAY_BG:=Color("c9a6aa")   # overridden by Room_Config backdrop.bg (e.g. sky blue for seaside rooms)
const NIGHT_BG:=Color("2a2438")

static func bl(v: Array) -> Vector3:
	# Blender (x, y, z up) -> Godot (x, y up, -y)
	return Vector3(v[0],v[2],-v[1])

func _ready() -> void:
	Engine.max_fps=30
	cfg=JSON.parse_string(FileAccess.get_file_as_string("res://assets/Room_Config.json"))
	views=cfg.get("views",[])
	cut_names=cfg.get("cutaway",[])
	mood=cfg.get("mood",{})
	cozy=str(cfg.get("light",""))=="cozy"
	backdrop=cfg.get("backdrop",{})
	if backdrop.has("bg"): DAY_BG=Color(backdrop["bg"])
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--capture-set="): capture_dir=arg.trim_prefix("--capture-set=")
		if arg.begins_with("--capture="): capture_path=arg.trim_prefix("--capture=")
	var doc:=GLTFDocument.new()
	var state:=GLTFState.new()
	var err:=doc.append_from_file(ProjectSettings.globalize_path("res://assets/Scene.glb"),state,GLTFDocument.IMPORT_FLAG_FORCE_DISABLE_MESH_COMPRESSION)
	if err!=OK:
		push_error("Scene load failed: %s" % err)
		get_tree().quit(1)
		return
	model=doc.generate_scene(state)
	add_child(model)
	for child in model.get_children():
		if child is Node3D:
			original_transforms[child]=child.transform
			original_visibility[child]=child.visible
	for node in model.find_children("*","MeshInstance3D",true,false):
		for s in range(node.mesh.get_surface_count()):
			total_triangles+=node.mesh.surface_get_arrays(s)[Mesh.ARRAY_INDEX].size()/3
			var mat: Material=node.mesh.surface_get_material(s)
			if mat is StandardMaterial3D:
				mat.texture_filter=BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
				for slot in ["albedo_texture","normal_texture","roughness_texture","metallic_texture","ao_texture","emission_texture"]:
					var t=mat.get(slot)
					if t: mat.set(slot,mipped(t))
				if mat.transparency!=BaseMaterial3D.TRANSPARENCY_DISABLED:
					mat.cull_mode=BaseMaterial3D.CULL_DISABLED;node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	for node in model.find_children("Slide_*","Node3D",true,false):slides[node]=node.position
	for node in model.find_children("Pivot_*","Node3D",true,false):
		if not node is MeshInstance3D:hinges[node]=node.rotation.y
	stage()
	build_ui()
	set_view(0)
	for arg in OS.get_cmdline_user_args():
		if arg=="--clean": ui.visible=false
		if arg=="--night": toggle_night()
		if arg=="--open": set_doors(true,true)
		if arg.begins_with("--view="): set_view(int(arg.trim_prefix("--view=")))
	print("ROOM_SCENE_LOADED ",total_triangles," triangles")
	if "--smoke-test" in OS.get_cmdline_user_args(): smoke_test.call_deferred()

func stage() -> void:
	world=WorldEnvironment.new()
	var env:=Environment.new()
	env.background_mode=Environment.BG_COLOR
	env.background_color=DAY_BG
	var sky:=Sky.new();sky.radiance_size=Sky.RADIANCE_SIZE_64
	sky_mat=ProceduralSkyMaterial.new()
	sky_mat.sky_top_color=Color("8cb9c7");sky_mat.sky_horizon_color=Color("e4d8b8")
	sky_mat.ground_bottom_color=Color("586950");sky_mat.ground_horizon_color=Color("d7c7a9")
	sky_mat.sky_energy_multiplier=.45;sky_mat.ground_energy_multiplier=.45
	sky.sky_material=sky_mat;env.sky=sky
	env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color=Color("e2d7cf");env.ambient_light_energy=.40*mk("ambient")
	env.reflected_light_source=Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode=Environment.TONE_MAPPER_LINEAR
	if cozy:
		env.ambient_light_source=Environment.AMBIENT_SOURCE_SKY;amb_day=.45;env.ambient_light_energy=amb_day*mk("ambient")
		sky_mat.sky_top_color=mc("sky_top",Color("8fadb6"));sky_mat.sky_horizon_color=mc("sky_horizon",Color("f2d7b0"))
		sky_mat.ground_bottom_color=mc("ground_bottom",Color("b49674"));sky_mat.ground_horizon_color=mc("ground_horizon",Color("dfcbb0"));sky_mat.sky_energy_multiplier=.65
		env.tonemap_mode=Environment.TONE_MAPPER_FILMIC;env.tonemap_exposure=.45   # kit renkleri Cozy setinden acik: olculerek eski parlakliga esitlendi
		if RenderingServer.get_current_rendering_method()!="gl_compatibility":
			env.ssao_enabled=true;env.ssao_radius=.18;env.ssao_intensity=1.6;env.ssao_detail=.75
			env.glow_enabled=true;env.glow_intensity=.12
	world.environment=env;add_child(world)
	key=DirectionalLight3D.new();key.rotation_degrees=Vector3(-48,140,0)
	key.sky_mode=DirectionalLight3D.SKY_MODE_LIGHT_ONLY;key.light_color=mc("key_color",Color("ffe5c5"));key.light_energy=.32*mk("key")
	key.shadow_enabled=true;key.directional_shadow_max_distance=18;key.shadow_bias=.1;key.shadow_normal_bias=1.6
	add_child(key)
	fill=DirectionalLight3D.new();fill.rotation_degrees=Vector3(-40,-25,0)
	fill.sky_mode=DirectionalLight3D.SKY_MODE_LIGHT_ONLY;fill.light_color=Color("b9bfd7");fill.light_energy=.15*mk("fill")
	add_child(fill)
	if cozy:   # gunes on-sagdan: arka ve sol duvar ici aydinlik, golgeler duvara duser
		key.rotation_degrees=Vector3(-50,35,0);key_day=.9;key.light_energy=key_day*mk("key");key.light_angular_distance=2.5
		fill_day=0.0;fill.light_energy=0.0
		for e in [[Vector3(0,5,3),Color("fff0d9"),.7],[Vector3(-2,3,-2),Color("d7f0ff"),.6]]:
			var o:=OmniLight3D.new();o.position=e[0];o.light_color=mc("fill_color",e[1]);o.light_energy=float(e[2])*mk("fill");o.omni_range=12;o.light_specular=.1
			add_child(o)
	var lo: Array=cfg.get("scene_bounds",[[0,0,0],[0,0,0]])[0]
	ground_y=float(lo[2])-.002
	ground=MeshInstance3D.new()
	var plane:=PlaneMesh.new();plane.size=Vector2(200,200);ground.mesh=plane
	ground.position.y=ground_y;ground.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var m:=ShaderMaterial.new();m.shader=load("res://cozy_stage.gdshader");ground.material_override=m
	if backdrop.has("ground"): m.set_shader_parameter("near_col",Vector3(Color(backdrop["ground"]).r,Color(backdrop["ground"]).g,Color(backdrop["ground"]).b))
	if backdrop.has("ground_far"): m.set_shader_parameter("far_col",Vector3(Color(backdrop["ground_far"]).r,Color(backdrop["ground_far"]).g,Color(backdrop["ground_far"]).b))
	add_child(ground)
	var lr: Array=mood.get("lamp_colors",[])
	for li in cfg.get("lamps",[]).size():
		var p: Array=cfg["lamps"][li]
		var lamp:=OmniLight3D.new();lamp.position=bl(p);lamp.light_color=Color(str(lr[li])) if li<lr.size() and lr[li]!=null else mc("lamp_color",Color("ffbd65"));lamp.light_energy=.85*mk("lamp")
		lamp.omni_range=float(mood.get("lamp_range",2.6));lamp.shadow_enabled=false;lamp.light_specular=.05
		add_child(lamp);lamps.append(lamp)
	camera=Camera3D.new();camera.fov=44;camera.near=.05;camera.far=350
	add_child(camera);camera.make_current()

func build_ui() -> void:
	ui=CanvasLayer.new();add_child(ui)
	var panel:=PanelContainer.new();panel.position=Vector2(20,20);panel.modulate=Color(1,1,1,.93);ui.add_child(panel)
	var margin:=MarginContainer.new()
	for side in ["left","right","top","bottom"]:margin.add_theme_constant_override("margin_"+side,14)
	panel.add_child(margin)
	var box:=VBoxContainer.new();box.add_theme_constant_override("separation",7);margin.add_child(box)
	var title:=Label.new();title.text=(String(cfg.get("series","Nasha's Cozy 3D"))+"  /  "+String(cfg.get("title","Room"))).to_upper()
	title.add_theme_font_size_override("font_size",20);box.add_child(title)
	var names:=[]
	for i in range(views.size()):names.append("%d %s"%[i+1,String(views[i]["name"]).replace("_"," ")])
	info=Label.new()
	info.text=" / ".join(names)+"\nDrag: orbit / right drag: pan / wheel: zoom\nN: day-night / E: doors / C: front wall / G: single model\nF: free camera (WASD, Q-E, Shift faster) / R: reset\nF1: hide interface / Esc: quit"
	info.add_theme_font_size_override("font_size",12);box.add_child(info)
	fps_label=Label.new();fps_label.add_theme_font_size_override("font_size",12);box.add_child(fps_label)
	picker=OptionButton.new();picker.focus_mode=Control.FOCUS_NONE;picker.custom_minimum_size=Vector2(325,30);box.add_child(picker)
	var manifest: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://assets/manifest.json"))
	entries=manifest.get("assets",[])
	for entry in entries:picker.add_item(String(entry["name"]).replace("_"," "))
	picker.item_selected.connect(func(_i):
		if gallery: exit_gallery(); enter_gallery())

func set_view(i: int) -> void:
	if views.is_empty():return
	i=clampi(i,0,views.size()-1)
	if gallery:exit_gallery()
	orbit=true;Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	var v: Dictionary=views[i]
	target=bl(v["target"]);yaw=float(v["yaw"]);pitch=float(v["pitch"]);distance=float(v["distance"])
	set_cutaway(true)
	key.directional_shadow_max_distance=clampf(distance*1.7,5.0,18.0)
	update_camera()

func update_camera() -> void:
	if orbit:
		camera.position=target+Vector3(sin(yaw)*cos(pitch),sin(pitch),cos(yaw)*cos(pitch))*distance
		camera.look_at(target)

func set_cutaway(value: bool) -> void:
	cutaway=value
	if gallery:return
	for node in original_transforms:
		if String(node.name) in cut_names:node.visible=not value

func set_doors(opened: bool, instant:=false) -> void:
	doors_open=opened
	if instant:
		for node in hinges:node.rotation.y=door_angle(node)
		for node in slides:node.position=slide_pos(node)

func door_angle(node) -> float:
	return hinges[node]+(-1.15 if doors_open else 0.0)

func slide_pos(node) -> Vector3:
	var p: Vector3=slides[node];p.x+=.6 if doors_open else 0.0;return p

func toggle_night() -> void:
	night=not night
	ground.material_override.set_shader_parameter("night_mix",1.0 if night else 0.0)
	key.light_energy=(.10 if night else key_day)*mk("key")
	key.light_color=Color("b5abc9") if night else mc("key_color",Color("ffe5c5"))
	fill.light_energy=(.08 if night and not cozy else fill_day)*mk("fill")
	world.environment.ambient_light_energy=(.22 if night else amb_day)*mk("ambient")
	world.environment.background_color=NIGHT_BG if night else DAY_BG
	sky_mat.sky_top_color=Color("172c47") if night else mc("sky_top",Color("8cb9c7"))
	sky_mat.sky_horizon_color=Color("6c6b7e") if night else mc("sky_horizon",Color("e4d8b8"))
	for lamp in lamps:lamp.light_energy=(1.3 if night else .85)*mk("lamp")

func bounds(node: Node3D) -> AABB:
	var first:=true;var result:=AABB()
	for child in node.find_children("*","MeshInstance3D",true,false):
		var b: AABB=child.global_transform*child.mesh.get_aabb()
		result=b if first else result.merge(b);first=false
	return result

func enter_gallery() -> void:
	if gallery or entries.is_empty():return
	var wanted: String=entries[picker.selected]["name"]
	for child in original_transforms:
		if String(child.name)==wanted:gallery_asset=child;break
	if not is_instance_valid(gallery_asset):return
	for child in original_transforms:child.visible=(child==gallery_asset)
	gallery=true
	for lamp in lamps:lamp.visible=false
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	ground.position.y=-.002
	var b:=bounds(gallery_asset);gallery_asset.global_position-=Vector3(b.get_center().x,b.position.y,b.get_center().z)
	b=bounds(gallery_asset);target=b.get_center();distance=maxf(.35,b.size.length()*1.4);yaw=.6;pitch=.25;orbit=true
	key.directional_shadow_max_distance=clampf(b.size.length()*3,3,35);update_camera()

func exit_gallery() -> void:
	if not gallery:return
	for child in original_transforms:child.transform=original_transforms[child];child.visible=original_visibility[child]
	ground.position.y=ground_y
	for lamp in lamps:lamp.visible=true
	gallery=false;gallery_asset=null;set_cutaway(cutaway)

func toggle_camera_mode() -> void:
	orbit=not orbit
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE if orbit else Input.MOUSE_MODE_CAPTURED
	if orbit:
		var back:=camera.basis.z.normalized()
		yaw=atan2(back.x,back.z);pitch=asin(clampf(back.y,-1,1))
		target=camera.position-back*distance

func _process(dt: float) -> void:
	fps_label.text="%d FPS · 30 FPS cap · %d triangles · %d models"%[Engine.get_frames_per_second(),total_triangles,entries.size()]
	if not orbit:
		var v:=Vector3(float(Input.is_physical_key_pressed(KEY_D))-float(Input.is_physical_key_pressed(KEY_A)),float(Input.is_physical_key_pressed(KEY_E))-float(Input.is_physical_key_pressed(KEY_Q)),float(Input.is_physical_key_pressed(KEY_S))-float(Input.is_physical_key_pressed(KEY_W)))
		camera.position+=(camera.basis*v).normalized()*dt*keyspeed*(2.5 if Input.is_physical_key_pressed(KEY_SHIFT) else 1.0)
	else:update_camera()
	for node in hinges:node.rotation.y=lerp_angle(node.rotation.y,door_angle(node),minf(dt*7,1))
	for node in slides:node.position=node.position.lerp(slide_pos(node),minf(1,dt*7))
	if capture_dir!="" or capture_path!="":capture_step()

func capture_step() -> void:
	frames+=1
	if frames!=24:return
	await RenderingServer.frame_post_draw
	var path:=capture_path if capture_dir=="" else capture_dir.path_join(String(views[capture_index]["name"])+".png")
	var error:=get_viewport().get_texture().get_image().save_png(path)
	print("ROOM_CAPTURE ",path," ",error)
	capture_index+=1
	if error!=OK or capture_dir=="" or capture_index>=views.size():get_tree().quit(error);return
	frames=0;set_view(capture_index)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		if orbit:
			if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):yaw-=event.relative.x*.006;pitch=clampf(pitch+event.relative.y*.005,-.15,1.25)
			if Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):target+=(-camera.basis.x*event.relative.x+camera.basis.y*event.relative.y)*distance*.001
		else:
			camera.rotate_y(-event.relative.x*.003);camera.rotate_object_local(Vector3.RIGHT,-event.relative.y*.003)
	if event is InputEventMouseButton and event.pressed and orbit:
		if event.button_index==MOUSE_BUTTON_WHEEL_UP:distance=maxf(.2,distance*.9)
		if event.button_index==MOUSE_BUTTON_WHEEL_DOWN:distance=minf(45,distance*1.1)
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode>=KEY_1 and event.keycode<=KEY_9:set_view(event.keycode-KEY_1);return
		match event.keycode:
			KEY_C:set_cutaway(not cutaway)
			KEY_E:
				if orbit:set_doors(not doors_open)
			KEY_N:toggle_night()
			KEY_G:
				if gallery:exit_gallery();set_view(0)
				else:enter_gallery()
			KEY_R:exit_gallery();set_view(0);set_doors(false,true)
			KEY_F:toggle_camera_mode()
			KEY_F1:ui.visible=not ui.visible
			KEY_ESCAPE:
				if not orbit:orbit=true;Input.mouse_mode=Input.MOUSE_MODE_VISIBLE;set_view(0)
				else:get_tree().quit()

func smoke_test() -> void:
	var manifest: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://assets/manifest.json"))
	assert(entries.size()==int(manifest["model_count"]),"Incomplete model manifest")
	var missing:=[]
	for i in range(entries.size()):
		picker.select(i);enter_gallery()
		if not gallery:missing.append(entries[i]["name"]);continue
		assert(absf(bounds(gallery_asset).position.y)<.001,"Gallery ground mismatch")
		exit_gallery()
	if not missing.is_empty():print("ROOM_MISSING ",missing);get_tree().quit(2);return
	for child in original_transforms:assert(child.transform.is_equal_approx(original_transforms[child]))
	set_doors(true,true);set_doors(false,true)
	for node in hinges:assert(is_equal_approx(node.rotation.y,hinges[node]),"Door reset mismatch")
	assert(views.size()>=4,"Need at least 4 views")
	for i in range(views.size()):set_view(i);assert(camera.position.is_finite(),"Camera invalid")
	toggle_night();toggle_night()
	print("ROOM_CONTROLS_OK ",entries.size()," models; ",views.size()," views; ",hinges.size()+slides.size()," moving parts")
	get_tree().quit()

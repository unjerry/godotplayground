NASHA'S COZY 3D: HAUNTED LIBRARY
================================

Hi, and thank you for picking up this pack!

A cozy Halloween home library at night in chestnut wood, sage, slate blue,
plum and pumpkin orange. A grand three bay bookcase holds twelve different
shelves of books with small Halloween treasures between them, with a rolling
ladder on a brass rail and a pair of owl bookends on top. A stone fireplace
with a real fire and a pumpkin garland warms a plum wingback and a moss
green wingback with a footstool, under a layered owl and moon relief
picture. A round reading table holds an open spellbook, a quill and a
chamberstick, a writing desk by the moon window carries a reading lamp, a
sealed letter and round spectacles, and a card catalogue, a book cart, a
floor globe, a pendulum clock and a friendly sheet ghost fill the rest.

In total: 41 models plus the room shell - 45 GLB files, each also as FBX.
Every model is low to mid poly (336 to 8.7k triangles), metre scale, with
solid-colour materials and no textures to manage.


WHERE THINGS ARE
----------------

Models/GLB/     One GLB per model, named after it. Metre scale, Y-up,
                origin on the floor (or on the wall mount for wall
                pieces).
Models/FBX/     The same models as FBX, for Unity, Unreal and others.
Models/models.json
                Name, description, size, triangles and moving parts of
                every model, in case you want to load things in code.
Blender/        Nashas_Cozy_Haunted_Library.blend
                The whole furnished room as one Blender file, with the
                original high-detail geometry. Saved with Blender 5.2;
                older Blender versions may not open it - the GLB and
                FBX files work everywhere.
Godot_Demo/     A small interactive viewer for Godot 4 (tested with 4.7).
                Windows: extract the ZIP first, then run Open_Demo.bat.
                It finds Godot in the usual places (Downloads, Desktop,
                Steam, PATH) or asks you to pick it once and remembers.
                Anywhere: open project.godot from the Godot project
                manager. Godot itself is not included.
Previews/       Room renders and a catalogue of all models.


THE MODELS
----------

Back_Wall       500 x 24 x 280 cm       1.5k tris
    Sage plaster wall with panelled dado and chestnut cornice.
Bankers_Reading_Lamp 29 x 32 x 44 cm         2.1k tris
    Weighted brass reading lamp with one curved neck and a hollow amber
    shade enclosing its bulb.
Basketweave_Floor 500 x 400 x 12 cm      16.1k tris
    Chestnut basket-weave floor with a continuous picture-frame border.
Book_Cart       70 x 39 x 73 cm         1.5k tris
    Two-tier book trolley with raised handles, panelled ends and four
    casters.
Bound_Journals  38 x 20 x 27 cm         3.0k tris
    Four broad green and ochre research journals on the lower trolley shelf.
Brass_Candelabra 35 x 19 x 50 cm         1.4k tris
    Three-branch brass candelabra with thick beeswax candles and wax drips.
Brass_Spectacle_Case 24 x 14 x 4.7 cm        1.7k tris
    Two round brass spectacles with a curved bridge and two visibly folded
    arms on a velvet-lined tray.
Card_Catalogue  106 x 56 x 113 cm       5.5k tris
    Twelve-drawer oak card catalogue turned toward the open floor with over
    70 cm of drawer clearance.
Chamber_Candlestick 16 x 12 x 23 cm          656 tris
    A short beeswax candle in a brass chamberstick with a curved finger
    handle.
Collection_01_Pumpkin 73 x 24 x 34 cm         3.3k tris
    Pumpkin with a distinct arrangement of varied leather volumes, plain
    colour bands and gaps.
Collection_02_Cauldron 64 x 24 x 34 cm         3.4k tris
    Cauldron with a distinct arrangement of varied leather volumes, plain
    colour bands and gaps.
Collection_03_Crow 67 x 24 x 35 cm         5.8k tris
    Crow with a distinct arrangement of varied leather volumes, plain colour
    bands and gaps.
Collection_04_Ghost 72 x 24 x 34 cm         6.9k tris
    Ghost with a distinct arrangement of varied leather volumes, plain
    colour bands and gaps.
Collection_05_Candle 59 x 24 x 33 cm         2.8k tris
    Candle with a distinct arrangement of varied leather volumes, plain
    colour bands and gaps.
Collection_06_Bat 74 x 24 x 34 cm         4.6k tris
    Bat with a distinct arrangement of varied leather volumes, plain colour
    bands and gaps.
Collection_07_Potion 72 x 23 x 34 cm         3.3k tris
    Potion with a distinct arrangement of varied leather volumes, plain
    colour bands and gaps.
Collection_08_Black_Cat 73 x 24 x 34 cm         7.5k tris
    Black_Cat with a distinct arrangement of varied leather volumes, plain
    colour bands and gaps.
Collection_09_Witch_Hat 70 x 23 x 34 cm         3.7k tris
    Witch_Hat with a distinct arrangement of varied leather volumes, plain
    colour bands and gaps.
Collection_10_Gourd 54 x 24 x 35 cm         2.6k tris
    Gourd with a distinct arrangement of varied leather volumes, plain
    colour bands and gaps.
Collection_11_Candy_Jar 73 x 23 x 34 cm         3.9k tris
    Candy_Jar with a distinct arrangement of varied leather volumes, plain
    colour bands and gaps.
Collection_12_Potion_Flask 64 x 23 x 32 cm         3.0k tris
    Potion_Flask with a distinct arrangement of varied leather volumes,
    plain colour bands and gaps.
Damson_Wingback_Armchair 84 x 77 x 136 cm        3.0k tris
    Damson wingback with swept wings, scroll arms and a welted cushion.
Floor_Globe     48 x 45 x 119 cm        8.7k tris
    Parchment globe in a brass meridian on a tall tripod chestnut floor
    stand.
Friendly_Sheet_Ghost 25 x 20 x 28 cm          844 tris
    Ivory ceramic sheet ghost with a scalloped hem, rounded head and two
    dark eyes.
Grand_Bookcase  296 x 63 x 243 cm       3.6k tris
    Three-bay chestnut bookcase with fluted pilasters, deep shelves and a
    stepped crown.
Harvest_Moon_Painting 100 x 5.0 x 78 cm       3.5k tris
    Layered cut relief picture of an owl on a branch before a full moon,
    with hills and pumpkins, in a brass frame over the fireplace.
Hearth_Log_Basket 20 x 34 x 32 cm          840 tris
    Narrow iron-handled firewood basket with three cut chestnut logs.
Leather_Footstool 47 x 34 x 30 cm          592 tris
    Low saddle-leather footstool with a plump cushion and cross stretchers.
Left_Wall       24 x 408 x 280 cm       1.7k tris
    Green panelled side wall with a real rectangular window opening.
Library_Service_Bell 16 x 16 x 16 cm          552 tris
    Small round brass service bell on a dark turned wood foot.
Moonlight_Window 130 x 58 x 127 cm       1.0k tris
    Recessed two-pane chestnut window with a deep sill and moon outside.
Olive_Wingback_Armchair 89 x 77 x 140 cm        3.1k tris
    Taller broad olive wing chair with rounded shoulders and ivory lumbar
    cushion.
Open_Spellbook  47 x 33 x 6.1 cm         392 tris
    Flat open mulberry book with one continuous cover, a bound spine and two
    gently curved blank page blocks.
Owl_Bookend_Pair 52 x 23 x 28 cm         2.5k tris
    Two different carved owl bookends supporting an oversized autumn folio.
Pendulum_Wall_Clock 49 x 20 x 84 cm         2.2k tris
    Chestnut pendulum clock with a glass-fronted hollow case and a free
    hanging brass bob.
Pumpkin_Mantel_Garland 90 x 16 x 16 cm         4.6k tris
    Five differently shaped ceramic pumpkins threaded on a draped brass
    cord.
Quill_And_Inkwell 18 x 12 x 44 cm          604 tris
    Square blue-black inkwell in a brass foot with a broad ivory feather
    quill.
Rear_Ceiling_Beams 366 x 189 x 22 cm        648 tris
    Three chamfered beams over the back half only.
Returned_Atlas_Stack 32 x 25 x 16 cm         1.3k tris
    Three broad returned atlases with irregularly turned covers.
Rolling_Ladder  46 x 63 x 223 cm        2.0k tris
    Splayed oak ladder with seven broad treads, curved brass hooks and iron
    rollers.
Round_Reading_Table 108 x 108 x 79 cm       2.1k tris
    Round chestnut reading table on a hexagonal pedestal with three swept
    feet.
Sealed_Letter_And_Blotter 31 x 27 x 4.0 cm         336 tris
    Leather blotter with a folded ivory letter and chunky red wax seal.
Sill_Candle_Lantern 17 x 15 x 30 cm          636 tris
    Squat hexagonal brass lantern with an ivory candle and a top carry ring.
Stone_Fireplace 121 x 84 x 126 cm       6.7k tris
    Sandstone fireplace with recessed mortar, a deep firebox and a stepped
    mantel.
Writing_Desk    120 x 55 x 79 cm        1.0k tris
    Chestnut writing desk with two brass-pull drawers and tapered square
    legs.


A FEW TIPS
----------

Every piece is a solid, separate model, so you can move, scale and reuse
each one on its own. The room is an open cutaway with two walls, so the
whole library is visible from the front.

There are no moving parts in this room.

The 53 materials have readable names like "Wood | Honey oak" and are shared
between models, so recolouring one material recolours that finish everywhere
in the set.

The room shell is split into parts: Basketweave_Floor (the floor), Back_Wall
and Left_Wall (the walls) and Rear_Ceiling_Beams (the ceiling beams).

The Godot demo has a night mode (press N) and shows each model on its own
(G). The fire, candles and lamp are glowing solid-colour geometry, not
lights, so add your own lights in your engine. There is no lettering
anywhere.

Tested: every GLB passes the Khronos glTF Validator with no errors, imports
cleanly into Blender 5.2 and runs in the Godot 4.7 demo; the FBX files were
checked by importing them back into Blender. Unity and Unreal were not
tested here; FBX is exported in metres with Y up.


Have fun building your rooms!
- Nasha

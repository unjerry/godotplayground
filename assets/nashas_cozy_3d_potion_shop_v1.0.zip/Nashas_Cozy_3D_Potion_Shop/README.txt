NASHA'S COZY 3D: HALLOWEEN POTION SHOP
======================================

Hi, and thank you for picking up this pack!

A sweet little witch's potion shop in apricot plaster, plum and sage. A sage
apothecary cabinet full of corked elixirs, a maple preparation table with
brass scales, a mortar and an open recipe book, a plum cauldron with glowing
mint potion in the brewing corner, a herb drying rack with hanging bundles,
and a scalloped shop counter with a ledger, a service bell and gift boxes. A
round moon window with a twilight forest view, fairy lights, a friendly
ghost lantern and a witch hat on its peg finish the mood.

In total: 48 models plus the room shell - 53 GLB files, each also as FBX.
Every model is low to mid poly (128 to 17.9k triangles), metre scale, with
solid-colour materials and no textures to manage.


WHERE THINGS ARE
----------------

Models/GLB/     One GLB per model, named after it. Metre scale, Y-up,
                origin on the floor (or on the wall mount for wall
                pieces). Moving parts are separate child nodes.
Models/FBX/     The same models as FBX, for Unity, Unreal and others.
Models/models.json
                Name, description, size, triangles and moving parts of
                every model, in case you want to load things in code.
Blender/        Nashas_Cozy_Potion_Shop.blend
                The whole furnished room as one Blender file, with the
                original high-detail geometry. Saved with Blender 5.2;
                older Blender versions may not open it - the GLB and
                FBX files work everywhere.
Godot_Demo/     A small interactive viewer for Godot 4 (tested with 4.7).
                Windows: extract the ZIP first, then run Open_Demo.bat.
                It finds Godot in the usual places (Downloads, Desktop,
                Steam, PATH) or asks you to pick it once and remembers.
                Anywhere: open project.godot from the Godot project
                manager. Godot itself is not included.
Previews/       Room renders and a catalogue of all models.


THE MODELS
----------

Apothecary_Book_Stack 34 x 38 x 26 cm         1.3k tris
    Three original plum, sage and honey recipe books stacked on the
    cupboard.
Apothecary_Packaging_Supplies 194 x 25 x 20 cm        1.3k tris
    Fitted kraft parcels, tied ingredient packets and parchment rolls on the
    cabinet counter.
Bottle_Shipping_Crate 69 x 52 x 52 cm         5.7k tris
    Open maple delivery crate with joined slats and two securely fitted
    bottles.
Brass_Balance_Scales 87 x 44 x 72 cm         1.6k tris
    Working-form balance with joined upright, hanging chains and two shallow
    weighing pans.
Brass_Shop_Hourglass 24 x 24 x 39 cm         1.5k tris
    Small glass hourglass with amber sand, brass columns and maple caps.
Brewing_Bench   283 x 90 x 94 cm         856 tris
    Maple preparation table with turned legs, joined apron and softly
    rounded top.
Brewing_Flask_Set 56 x 27 x 46 cm         3.8k tris
    Two differently shaped corked mixing flasks beside the cauldron.
Ceiling_Panel   790 x 505 x 340 cm      1.2k tris
    Removable shopfront panels and overhead beams; C toggles the facade.
Counter_Potion_Display 34 x 30 x 34 cm         3.9k tris
    A cream display tray with two signature elixirs.
Counter_Service_Bell 28 x 28 x 21 cm          976 tris
    Small brass counter bell on a maple foot.
Crooked_Broom   37 x 25 x 153 cm        1.6k tris
    Maple broom with a bound straw bundle resting on the shop floor.
Crystal_Infusion_Tray 44 x 26 x 30 cm          606 tris
    Cream window-ledge tray of three faceted mint and lavender infusion
    crystals.
Entrance_Door   142 x 14 x 234 cm        996 tris
    Sage entrance door with left hinge, cream panels and vertical brass
    ring. Moving: Pivot_Entry.
Fresh_Herb_Planter 46 x 36 x 59 cm         6.9k tris
    Ribbed cream floor pot with fresh sage foliage and lavender sprigs.
Friendly_Ghost_Lantern 44 x 44 x 82 cm         4.0k tris
    Friendly ghost lantern on a brass foot with a small ring handle.
Hanging_Herb_Bundles 163 x 11 x 61 cm       17.9k tris
    Five tied bundles of sage, lavender and autumn foliage below the drying
    rail.
Hanging_Potion_Shop_Sign 66 x 13 x 24 cm         1.6k tris
    Small maple counter plaque with POTIONS lettering and brass mounts.
Herb_Drying_Rack 190 x 24 x 14 cm         128 tris
    Brass wall rack and wooden rail with physical wall brackets.
Herbalist_Drawer_Cupboard 184 x 79 x 114 cm       3.9k tris
    Sage apothecary joinery with rounded maple cornice, open shelves and
    fitted drawer fronts.
Herbalist_Tool_Roll 40 x 22 x 4.3 cm         932 tris
    Sage cloth tool roll with measuring spoons, a small spatula and cream
    stitched hems.
Ingredient_Herb_Jars 135 x 31 x 37 cm        3.3k tris
    Three fitted ceramic ingredient canisters with matching lids and leaf
    seals.
Ingredient_Sacks 62 x 39 x 49 cm         4.0k tris
    Two rounded linen ingredient sacks with bound tops.
Ingredient_Sampling_Tray 36 x 31 x 14 cm         2.3k tris
    Small tray with mushrooms, sage leaves and an ingredient scoop.
Leafy_Shop_Wreath 87 x 12 x 85 cm         2.7k tris
    Creased autumn-leaf wreath and plum ribbon above the herbalist corner.
Little_Cauldron 115 x 86 x 69 cm        5.4k tris
    Hollow plum kettle on three brass feet, with mint potion, rim, side
    handles and glowing bubbles.
Lower_Shelf_Elixirs 230 x 22 x 42 cm       12.6k tris
    Grouped corked elixirs in varied bottle silhouettes, with opaque liquid
    and cream seals.
Maple_Stirring_Spoon 70 x 12 x 73 cm          560 tris
    Long maple stirring spoon resting inside the cauldron.
Middle_Shelf_Tonics 195 x 22 x 48 cm       10.9k tris
    Grouped corked elixirs in varied bottle silhouettes, with opaque liquid
    and cream seals.
Moon_Floor_Lamp 95 x 50 x 220 cm        1.4k tris
    Warm lantern lamp with a curved brass bracket and glass-free honey
    light.
Moon_Preparation_Table 215 x 112 x 90 cm        856 tris
    Maple preparation table with turned legs, joined apron and softly
    rounded top.
Moon_Wall_Clock 56 x 11 x 56 cm         1.2k tris
    Cream circular shop clock with twelve brass hour marks and two plum
    hands.
Moon_and_Star_Mobile 42 x 16 x 69 cm          784 tris
    Small hanging brass crescent and stars on threads with physical wall
    pins.
Mortar_and_Pestle 38 x 38 x 33 cm         1.4k tris
    Hollow cream mortar, ground herbs and a fitted leaning maple pestle.
Mushroom_Ingredient_Basket 42 x 42 x 26 cm         3.5k tris
    Little woven basket of soft pink and cream mushrooms.
Open_Recipe_Book 57 x 46 x 6.6 cm        1.5k tris
    Open recipe book with curved cream pages, hand-drawn potion diagram and
    brass page corners.
Plum_Shop_Runner 122 x 390 x 2.6 cm       236 tris
    Plum runner rug with cream stitched border and leaf corner motifs.
Potion_Gift_Boxes 62 x 34 x 36 cm         3.0k tris
    Two small gift boxes with fitted lids and soft sage ribbon bows.
Potion_Sidewalk_Sign 56 x 57 x 93 cm         2.1k tris
    Free-standing little A-frame with POTIONS lettering and a raised bottle
    icon.
Pumpkin_Delivery_Basket 94 x 94 x 63 cm         9.2k tris
    Round harvest basket with three soft pumpkins and woven bands.
Recipe_Wall_Plaque 80 x 7.2 x 63 cm         504 tris
    Original illustrated recipe panel with bottle diagram and hand-drawn
    ingredient lines.
Room_Walls      807 x 681 x 340 cm      2.3k tris
    Apricot plaster, plum wainscot and a real circular rear window opening.
Round_Maple_Stool 58 x 58 x 54 cm         2.2k tris
    Little round shop stool with turned feet and a plum padded top.
Round_Moon_Window 220 x 48 x 202 cm       3.2k tris
    Deep circular maple and vanilla window frame with brass radial accents.
Sage_Apothecary_Cabinet 303 x 81 x 290 cm       4.7k tris
    Sage apothecary joinery with rounded maple cornice, open shelves and
    fitted drawer fronts.
Shop_Fairy_Lights 770 x 343 x 44 cm      15.1k tris
    Two warm string lights physically joined to the wall and timber posts.
Shop_Ledger_and_Ink 71 x 43 x 45 cm         1.7k tris
    Plum sales ledger, glass ink bottle and feather quill.
Shop_Service_Counter 283 x 98 x 112 cm       5.5k tris
    Sage shop counter with scalloped maple top, cream front panels and a
    small moon medallion.
Stone_Floor     840 x 725 x 37 cm      10.3k tris
    Warm maple shop floor with a rounded cocoa foundation; 7.8 x 6.6 metre
    interior.
Twilight_Window_View 230 x 11 x 231 cm       5.4k tris
    Removable layered forest-and-moon scenic panel behind the circular
    window.
Upper_Shelf_Remedies 211 x 24 x 40 cm        9.3k tris
    Grouped corked elixirs in varied bottle silhouettes, with opaque liquid
    and cream seals.
Welcome_Mat     135 x 40 x 2.8 cm       1.4k tris
    Soft sage entry mat with a smiling moon motif.
Window_Glass    181 x 0.6 x 181 cm       512 tris
    Single round clear glass pane.
Witch_Hat_on_Peg 64 x 64 x 59 cm         1.2k tris
    Soft plum witch hat on a physically attached maple peg.


A FEW TIPS
----------

Every piece is a solid, separate model, so you can move, scale and reuse
each one on its own. The entrance door swings on a real hinge node, and the
shopfront panels with the overhead beams (Ceiling_Panel) are their own part,
so you can show the shop as an open cutaway or close it in.

In glTF and Godot axes, Pivot_ nodes (door hinges) swing around their local
Y axis. Nothing is baked as an animation clip, so you animate them the way
your game needs (the Godot demo shows one way in a few lines of code).

The 36 materials have readable names like "Wood | Honey oak" and are shared
between models, so recolouring one material recolours that finish everywhere
in the set.

The room shell is split into parts: Stone_Floor (the maple floor),
Room_Walls, Round_Moon_Window, Window_Glass and Ceiling_Panel (the shopfront
panels and overhead beams). Twilight_Window_View is a forest and moon
backdrop panel behind the round window.

The Godot demo has an evening mode (press N) and shows each model on its own
(G). The cauldron bubbles, fairy lights and lantern glow are solid-colour
geometry, not lights, so add your own lights in your engine.

The POTIONS lettering on the sidewalk sign and the counter plaque is
modelled geometry. Bottle groups (Lower_Shelf_Elixirs and the other shelf
sets) are single models.

Tested: every GLB passes the Khronos glTF Validator with no errors, imports
cleanly into Blender 5.2 and runs in the Godot 4.7 demo; the FBX files were
checked by importing them back into Blender. Unity and Unreal were not
tested here; FBX is exported in metres with Y up.


Have fun building your rooms!
- Nasha

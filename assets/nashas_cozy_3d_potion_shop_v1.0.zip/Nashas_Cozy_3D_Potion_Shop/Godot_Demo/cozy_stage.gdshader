shader_type spatial;
render_mode diffuse_burley;
varying vec3 world_position;
uniform float night_mix=0.0;
void vertex(){world_position=(MODEL_MATRIX*vec4(VERTEX,1.0)).xyz;}
void fragment(){
 float fade=smoothstep(3.0,20.0,length(world_position.xz));
 vec3 warm=mix(vec3(0.49,0.43,0.38),vec3(0.22,0.18,0.30),fade);
 vec3 cool=mix(vec3(0.25,0.20,0.30),vec3(0.08,0.065,0.13),fade);
 ALBEDO=mix(warm,cool,night_mix);ROUGHNESS=1.0;SPECULAR=0.0;
}

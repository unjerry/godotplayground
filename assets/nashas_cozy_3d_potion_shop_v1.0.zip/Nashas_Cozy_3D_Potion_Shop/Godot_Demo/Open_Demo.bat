@echo off
setlocal EnableDelayedExpansion
rem Opens this Godot 4 demo project (tested with Godot 4.7, https://godotengine.org).
rem Godot is looked for in: the GODOT_EXE variable, a path saved in godot_path.txt, this folder and the
rem folder above it, your Downloads and Desktop folders (the file as downloaded, e.g. Godot_v4.4-stable_win64.exe),
rem the Steam version and PATH. If none is found, a window asks you to pick it once and remembers it.
rem Options: /editor opens the project in the Godot editor, /safe uses the Compatibility renderer (older GPUs),
rem /which only shows which Godot would be used.
cd /d "%~dp0"
set "COZY_PROJECT=%~dp0"
if "%COZY_PROJECT:~-1%"=="\" set "COZY_PROJECT=%COZY_PROJECT:~0,-1%"
if not exist "%COZY_PROJECT%\project.godot" (
    echo This file was started from inside the ZIP, or the demo files are missing.
    echo Right-click the ZIP, choose Extract All, then run Godot_Demo\Open_Demo.bat
    echo from the extracted folder.
    pause
    exit /b 3
)
set "COZY_ENGINE="
if defined GODOT_EXE if exist "%GODOT_EXE%" set "COZY_ENGINE=%GODOT_EXE%"
if not defined COZY_ENGINE if exist "%~dp0godot_path.txt" (
    set /p COZY_SAVED=<"%~dp0godot_path.txt"
    if exist "!COZY_SAVED!" set "COZY_ENGINE=!COZY_SAVED!"
)
for %%D in ("%~dp0." "%~dp0.." "%USERPROFILE%\Downloads" "%USERPROFILE%\Desktop") do (
    if not defined COZY_ENGINE if exist "%%~D\godot.exe" set "COZY_ENGINE=%%~D\godot.exe"
    if not defined COZY_ENGINE for %%F in ("%%~D\Godot_v4*_win64.exe") do if not exist "%%~F\" set "COZY_ENGINE=%%~fF"
    if not defined COZY_ENGINE for /d %%S in ("%%~D\Godot_v4*") do for %%F in ("%%~S\Godot_v4*_win64.exe") do if not exist "%%~F\" set "COZY_ENGINE=%%~fF"
)
set "COZY_STEAM=%ProgramFiles(x86)%\Steam\steamapps\common\Godot Engine\godot.windows.opt.tools.64.exe"
if not defined COZY_ENGINE if exist "%COZY_STEAM%" set "COZY_ENGINE=%COZY_STEAM%"
if not defined COZY_ENGINE for /f "delims=" %%G in ('where godot.exe 2^>nul') do set "COZY_ENGINE=%%G"
if not defined COZY_ENGINE for /f "delims=" %%G in ('where godot4.exe 2^>nul') do set "COZY_ENGINE=%%G"
if not defined COZY_ENGINE if /i not "%~1"=="/which" (
    echo Godot 4 was not found automatically. Please pick your Godot executable in the window that opens.
    for /f "usebackq delims=" %%G in (`powershell -NoProfile -STA -Command "Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.OpenFileDialog; $d.Title = 'Select your Godot 4 executable'; $d.Filter = 'Godot (*.exe)|*.exe'; if ($d.ShowDialog() -eq 'OK') { $d.FileName }"`) do set "COZY_ENGINE=%%G"
    if defined COZY_ENGINE (>"%~dp0godot_path.txt" echo !COZY_ENGINE!)
)
if /i "%~1"=="/which" (
    if defined COZY_ENGINE (echo Godot: !COZY_ENGINE!) else (echo Godot: not found)
    exit /b 0
)
if not defined COZY_ENGINE (
    echo Godot 4 was not found. Download it from https://godotengine.org and run this file again,
    echo or open project.godot from the Godot project manager.
    pause
    exit /b 1
)
if not exist "%COZY_PROJECT%\.godot\imported" (
    echo Preparing the scene for the first launch, this takes a moment...
    start "Cozy import" /wait /belownormal "%COZY_ENGINE%" --headless --editor --path "%COZY_PROJECT%" --import --quit
    if errorlevel 1 exit /b 2
)
if /i "%~1"=="/editor" (
    start "" "%COZY_ENGINE%" --editor --path "%COZY_PROJECT%"
    exit /b 0
)
if /i "%~1"=="/safe" (
    start "" "%COZY_ENGINE%" --path "%COZY_PROJECT%" --rendering-method gl_compatibility --max-fps 60
) else (
    start "" "%COZY_ENGINE%" --path "%COZY_PROJECT%" --max-fps 60
)

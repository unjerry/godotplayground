extends Node3D
var model: Node3D
var camera: Camera3D
var target:=Vector3(0,1.35,.6)
var yaw:=.56
var pitch:=.40
var distance:=18.5
var orbit:=true
var keyspeed:=4.0
var ui: CanvasLayer
var info: Label
var picker: OptionButton
var world: WorldEnvironment
var key: DirectionalLight3D
var sun: ProceduralSkyMaterial
var fill: DirectionalLight3D
var ground: MeshInstance3D
var night:=false
var gallery:=false
var gallery_asset: Node3D
var original_transforms: Dictionary={}
var original_visibility: Dictionary={}
var entries: Array=[]
var slides: Dictionary={}
var doors_open:=false
var cutaway:=false
var hinges: Dictionary={}
var fps_label: Label
var capture_dir:=""
var capture_path:=""
var frames:=0
var capture_index:=0
var review_views: Array[int]=[]
var capture_busy:=false
var captures:=["Overview", "Welcome", "Preparation_Table", "Brewing_Corner", "Elixir_Shelves", "Herb_Corner", "Shop_Counter", "Exterior"]
var total_triangles:=0

func _ready() -> void:
	Engine.max_fps=30
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--capture-set="): capture_dir=arg.trim_prefix("--capture-set=")
		if arg.begins_with("--capture="): capture_path=arg.trim_prefix("--capture=")
		if arg=="--audit-set": captures.append_array(["Interior","Left","Right"])
	if capture_dir!="" or capture_path!="": Engine.max_fps=20
	var doc:=GLTFDocument.new()
	var state:=GLTFState.new()
	var err:=doc.append_from_file(ProjectSettings.globalize_path("res://assets/Scene.glb"),state,GLTFDocument.IMPORT_FLAG_FORCE_DISABLE_MESH_COMPRESSION)
	if err!=OK:
		push_error("Room load failed: %s" % err)
		get_tree().quit(1)
		return
	model=doc.generate_scene(state)
	add_child(model)
	for child in model.get_children():
		if child is Node3D:
			original_transforms[child]=child.transform
			original_visibility[child]=child.visible
	for node in model.find_children("*","MeshInstance3D",true,false):
		if "Glass" in String(node.name) or "Glazing" in String(node.name):
			node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		for s in range(node.mesh.get_surface_count()):
			var arrays: Array=node.mesh.surface_get_arrays(s)
			total_triangles+=arrays[Mesh.ARRAY_INDEX].size()/3
			var mat: Material=node.mesh.surface_get_material(s)
			if mat is StandardMaterial3D:
				mat.texture_filter=BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
				if mat.resource_name.begins_with("Screen |"):
					mat.metallic_specular=.12
				if "Clear glass" in mat.resource_name:
					mat.cull_mode=BaseMaterial3D.CULL_DISABLED;mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA;mat.albedo_color.a=.105;mat.roughness=.12
				if mat.resource_name.begins_with("Leaf") or mat.resource_name.begins_with("Flower"):mat.cull_mode=BaseMaterial3D.CULL_DISABLED
				if mat.resource_name.begins_with("Maple") or mat.resource_name.begins_with("Grass"):
					mat.cull_mode=BaseMaterial3D.CULL_DISABLED
	for node in model.find_children("Slide_*","Node3D",true,false):
		if node.name=="Slide_Left" or node.name=="Slide_Right": slides[node]=node.position
	for node in model.find_children("Pivot_*","Node3D",true,false):
		if not node is MeshInstance3D:hinges[node]=node.rotation.y
	set_doors(false,true)
	stage()
	build_ui()
	set_view(0)
	for arg in OS.get_cmdline_user_args():
		if arg=="--clean": ui.visible=false
		if arg.begins_with("--capture-views="):
			for value in arg.trim_prefix("--capture-views=").split(","):review_views.append(clampi(value.to_int(),0,7))
		if arg=="--gate": set_view(1)
		if arg=="--shrine": set_view(2)
		if arg=="--rear": set_view(4)
		if arg=="--basin": set_view(3)
		if arg=="--night": toggle_night()
		if arg=="--open":set_doors(true,true)
		if arg.begins_with("--view="):set_view(int(arg.trim_prefix("--view=")))
		if arg.begins_with("--asset="):
			var wanted:=arg.trim_prefix("--asset=")
			for i in range(entries.size()):
				if entries[i]["name"]==wanted:picker.select(i);enter_gallery();break
	if not review_views.is_empty():set_view(review_views[0])
	print("MODERN_ROOM_SCENE_LOADED ",total_triangles," triangles; ",slides.size()," optional moving leaves")
	if "--smoke-test" in OS.get_cmdline_user_args(): smoke_test.call_deferred()

func stage() -> void:
	world=WorldEnvironment.new()
	var env:=Environment.new()
	env.background_mode=Environment.BG_COLOR
	env.background_color=Color("c9a6aa")
	var sky:=Sky.new()
	sky.radiance_size=Sky.RADIANCE_SIZE_64
	sun=ProceduralSkyMaterial.new()
	sun.sky_top_color=Color("8cb9c7")
	sun.sky_horizon_color=Color("e4d8b8")
	sun.ground_bottom_color=Color("586950")
	sun.ground_horizon_color=Color("d7c7a9")
	sun.sun_angle_max=5
	sun.sky_energy_multiplier=.45
	sun.ground_energy_multiplier=.45
	sky.sky_material=sun
	env.sky=sky
	env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color=Color("e2d7cf")
	env.ambient_light_energy=.40
	env.reflected_light_source=Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode=Environment.TONE_MAPPER_LINEAR
	env.tonemap_exposure=1.0
	env.fog_enabled=true;env.fog_light_color=Color("c9a6aa");env.fog_density=.001
	world.environment=env
	add_child(world)
	key=DirectionalLight3D.new()
	key.rotation_degrees=Vector3(-48,140,0)
	key.sky_mode=DirectionalLight3D.SKY_MODE_LIGHT_ONLY
	key.light_color=Color("ffe5c5")
	key.light_energy=.32
	key.shadow_enabled=true
	key.directional_shadow_max_distance=18
	key.shadow_bias=.10
	key.shadow_normal_bias=1.6
	add_child(key)
	fill=DirectionalLight3D.new()
	fill.rotation_degrees=Vector3(-40,-25,0)
	fill.sky_mode=DirectionalLight3D.SKY_MODE_LIGHT_ONLY
	fill.light_color=Color("b9bfd7")
	fill.light_energy=.15
	add_child(fill)
	var floor:=MeshInstance3D.new()
	ground=floor
	var plane:=PlaneMesh.new();plane.size=Vector2(200,200);floor.mesh=plane
	floor.position.y=-.335
	floor.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var mat:=ShaderMaterial.new();mat.shader=load("res://cozy_stage.gdshader");floor.material_override=mat
	add_child(floor)
	for p in [Vector3(1.9,1.65,-2.68),Vector3(3.0,1.8,-1.05),Vector3(-1.72,2.5,-2.35),Vector3(1.5,2.6,1.48)]:
		var lamp:=OmniLight3D.new();lamp.position=p;lamp.light_color=Color("b9f6ce") if p.distance_to(Vector3(1.90,1.65,-2.68))<.05 else Color("ffe3b6");lamp.light_energy=0.39;lamp.omni_range=3.6;lamp.shadow_enabled=false;lamp.light_specular=.015;
		if p.distance_to(Vector3(1.90,1.65,-2.68))<.05:lamp.light_energy=.25;lamp.omni_range=1.65
		add_child(lamp)
	camera=Camera3D.new();camera.fov=44;camera.near=.05;camera.far=350
	add_child(camera);camera.make_current()

func build_ui() -> void:
	ui=CanvasLayer.new();add_child(ui)
	var panel:=PanelContainer.new();panel.position=Vector2(20,20);panel.modulate=Color(1,1,1,.93);ui.add_child(panel)
	var margin:=MarginContainer.new();margin.add_theme_constant_override("margin_left",16);margin.add_theme_constant_override("margin_right",16);margin.add_theme_constant_override("margin_top",12);margin.add_theme_constant_override("margin_bottom",12);panel.add_child(margin)
	var box:=VBoxContainer.new();box.add_theme_constant_override("separation",7);margin.add_child(box)
	var title:=Label.new();title.text="NASHA'S COZY 3D  /  HALLOWEEN POTION SHOP";title.add_theme_font_size_override("font_size",20);box.add_child(title)
	info=Label.new();info.text="Halloween potion shop\n1: Overview\n2: Welcome\n3: Preparation Table\n4: Brewing Corner\n5: Elixir Shelves\n6: Herb Corner\n7: Shop Counter\n8: Exterior\nC: Front frame and ceiling · E: Door\nLeft mouse: rotate · Right mouse: pan · Wheel: zoom\nF: Free camera (WASD / Q-E) · Shift: faster\nN: Evening light · G: Inspect model · R: Reset\nF1: Hide interface · Esc: Quit";info.add_theme_font_size_override("font_size",12);box.add_child(info)
	fps_label=Label.new();fps_label.add_theme_font_size_override("font_size",12);box.add_child(fps_label)
	picker=OptionButton.new();picker.focus_mode=Control.FOCUS_NONE;picker.custom_minimum_size=Vector2(325,30);box.add_child(picker)
	var manifest: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://assets/manifest.json"))
	entries=manifest.get("assets",[])
	for entry in entries: picker.add_item(String(entry["name"]).replace("_"," "))
	picker.item_selected.connect(func(_i):
		if gallery: exit_gallery(); enter_gallery())

func set_view(i: int) -> void:
	if gallery:exit_gallery()
	orbit=true;Input.mouse_mode=Input.MOUSE_MODE_VISIBLE;camera.fov=44
	set_cutaway(not [7].has(i))
	ground.visible=i==0
	for node in original_transforms:
		if String(node.name)=="Skyline_Backdrop":node.visible=i!=0
	for pattern in ["Right_Upper_Wall","Right_Wet_Tiles"]:
		for panel in model.find_children(pattern,"Node3D",true,false):panel.visible=i!=0
	match i:
		0:target=Vector3(0,1.4,0);yaw=0.61;pitch=0.47;distance=15.1
		1:target=Vector3(0,1.4,0.25);yaw=0.08;pitch=0.21;distance=11.7
		2:target=Vector3(-1.75,1.16,0.7);yaw=0.26;pitch=0.49;distance=4.2
		3:target=Vector3(1.78,1.65,-2.68);yaw=-0.38;pitch=0.34;distance=4.8
		4:target=Vector3(-1.72,1.92,-2.85);yaw=0.15;pitch=0.13;distance=4.8
		5:target=Vector3(-3.3,1.85,-0.75);yaw=0.72;pitch=0.2;distance=4.5
		6:target=Vector3(2.2,1.2,1.48);yaw=-0.4;pitch=0.39;distance=4.7
		7:target=Vector3(0,1.55,1.35);yaw=0.52;pitch=0.34;distance=14.7
	key.directional_shadow_max_distance=clampf(distance*1.7,5.0,18.0)
	update_camera()

func update_camera() -> void:
	if orbit:
		camera.position=target+Vector3(sin(yaw)*cos(pitch),sin(pitch),cos(yaw)*cos(pitch))*distance
		camera.look_at(target)

func set_cutaway(value: bool) -> void:
	cutaway=value
	if gallery:return
	for node in original_transforms:
		if String(node.name) in ["Ceiling_Panel","Entrance_Door"]:node.visible=not value
func set_doors(opened: bool, instant:=false) -> void:
	doors_open=opened
	if instant:
		for node in hinges:node.rotation.y=hinges[node]+(-1.15) if opened else hinges[node]
	if instant:
		for node in slides:
			var p: Vector3=slides[node];p.x+=1.64 if opened else 0.0;node.position=p

func toggle_night() -> void:
	night=not night
	ground.material_override.set_shader_parameter("night_mix",1.0 if night else 0.0)
	key.light_energy=.10 if night else .32
	fill.light_energy=.08 if night else .15
	world.environment.ambient_light_energy=.25 if night else .40
	world.environment.background_color=Color("30293f") if night else Color("c9a6aa")
	key.light_color=Color("b5abc9") if night else Color("ffe5c5")
	world.environment.fog_light_color=Color("30293f") if night else Color("c9a6aa")
	sun.sky_top_color=Color("172c47") if night else Color("8cb9c7")
	sun.sky_horizon_color=Color("6c6b7e") if night else Color("e4d8b8")

func bounds(node: Node3D) -> AABB:
	var first:=true;var result:=AABB()
	for child in node.find_children("*","MeshInstance3D",true,false):
		var b: AABB=child.global_transform*child.mesh.get_aabb()
		result=b if first else result.merge(b);first=false
	return result

func enter_gallery() -> void:
	if gallery or entries.is_empty():return
	var name: String=entries[picker.selected]["name"]
	for child in original_transforms:
		if String(child.name)==name:gallery_asset=child;break
	if not is_instance_valid(gallery_asset):return
	for pattern in ["Right_Upper_Wall","Right_Wet_Tiles"]:
		for panel in gallery_asset.find_children(pattern,"Node3D",true,false):panel.visible=true
	for child in original_transforms:child.visible=(child==gallery_asset)
	gallery=true;ground.visible=true
	for light in get_children():
		if light is OmniLight3D:light.visible=false
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	ground.position.y=-.002
	var b:=bounds(gallery_asset);gallery_asset.global_position-=Vector3(b.get_center().x,b.position.y,b.get_center().z)
	b=bounds(gallery_asset);target=b.get_center();distance=maxf(.35,b.size.length()*1.4);yaw=.6;pitch=.25;orbit=true;key.directional_shadow_max_distance=clampf(b.size.length()*3,3,35);update_camera()

func exit_gallery() -> void:
	if not gallery:return
	for child in original_transforms:child.transform=original_transforms[child];child.visible=original_visibility[child]
	ground.position.y=-.335
	key.directional_shadow_max_distance=18
	for light in get_children():
		if light is OmniLight3D:light.visible=true
	gallery=false;gallery_asset=null;set_cutaway(cutaway)

func toggle_camera_mode() -> void:
	orbit=not orbit
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE if orbit else Input.MOUSE_MODE_CAPTURED
	if orbit:
		var back:=camera.basis.z.normalized()
		yaw=atan2(back.x,back.z);pitch=asin(clampf(back.y,-1,1))
		target=camera.position-back*distance

func _process(dt: float) -> void:
	if is_instance_valid(fps_label):fps_label.text="%d FPS · %s · %d triangles"%[Engine.get_frames_per_second(),"30 FPS cap",total_triangles]
	if not orbit:
		var v:=Vector3(Input.get_axis("ui_left","ui_right"),0,Input.get_axis("ui_up","ui_down"))
		v=Vector3(float(Input.is_physical_key_pressed(KEY_D))-float(Input.is_physical_key_pressed(KEY_A)),float(Input.is_physical_key_pressed(KEY_E))-float(Input.is_physical_key_pressed(KEY_Q)),float(Input.is_physical_key_pressed(KEY_S))-float(Input.is_physical_key_pressed(KEY_W)))
		camera.position+=(camera.basis*v).normalized()*dt*keyspeed*(2.5 if Input.is_physical_key_pressed(KEY_SHIFT) else 1.0)
	else:update_camera()
	for node in hinges:
		var angle: float=hinges[node]+(-1.15) if doors_open else hinges[node];node.rotation.y=lerp_angle(node.rotation.y,angle,minf(dt*7,1))
	for node in slides:
		var p: Vector3=slides[node];p.x+=1.64 if doors_open else 0.0
		node.position=node.position.lerp(p,minf(1,dt*7))
	if (capture_dir!="" or capture_path!="") and not capture_busy:
		frames+=1
		if frames==24:
			capture_busy=true
			await RenderingServer.frame_post_draw
			var path:=capture_path if capture_dir=="" else capture_dir.path_join(captures[review_views[capture_index] if not review_views.is_empty() else capture_index]+".png")
			var error:=get_viewport().get_texture().get_image().save_png(path)
			print("MODERN_ROOM_CAPTURE ",path," ",error)
			if error!=OK:get_tree().quit(error);return
			capture_index+=1
			if capture_dir=="" or capture_index==(review_views.size() if not review_views.is_empty() else captures.size()):get_tree().quit();return
			frames=0;set_view(review_views[capture_index] if not review_views.is_empty() else capture_index);capture_busy=false

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		if orbit:
			if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):yaw-=event.relative.x*.006;pitch=clampf(pitch+event.relative.y*.005,-.15,1.25)
			if Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):target+=(-camera.basis.x*event.relative.x+camera.basis.y*event.relative.y)*distance*.001
		else:
			camera.rotate_y(-event.relative.x*.003);camera.rotate_object_local(Vector3.RIGHT,-event.relative.y*.003)
	if event is InputEventMouseButton and event.pressed and orbit:
		if event.button_index==MOUSE_BUTTON_WHEEL_UP:distance=maxf(.20,distance*.9)
		if event.button_index==MOUSE_BUTTON_WHEEL_DOWN:distance=minf(45,distance*1.1)
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_1: set_view(0)
			KEY_2: set_view(1)
			KEY_3: set_view(2)
			KEY_4: set_view(3)
			KEY_5:set_view(4)
			KEY_6:set_view(5)
			KEY_7:set_view(6)
			KEY_8:set_view(7)
			KEY_C:set_cutaway(not cutaway)
			KEY_E:
				if orbit:set_doors(not doors_open)
			KEY_N: toggle_night()
			KEY_G:
				if gallery:exit_gallery();set_view(0)
				else:enter_gallery()
			KEY_R: exit_gallery();set_view(0);set_doors(false,true)
			KEY_F:
				toggle_camera_mode()
			KEY_F1:ui.visible=not ui.visible
			KEY_ESCAPE:
				if not orbit:orbit=true;Input.mouse_mode=Input.MOUSE_MODE_VISIBLE;set_view(0)
				else:get_tree().quit()

func smoke_test() -> void:
	assert(entries.size()==53,"Incomplete model manifest")
	for i in range(entries.size()):
		picker.select(i);enter_gallery();assert(gallery,"Missing gallery model");assert(absf(bounds(gallery_asset).position.y)<.0001,"Gallery ground mismatch");exit_gallery()
	for child in original_transforms:assert(child.transform.is_equal_approx(original_transforms[child]))
	assert(hinges.size()==1,"Moving assembly count mismatch")
	set_doors(true,true)
	for node in hinges:assert(is_equal_approx(node.rotation.y,hinges[node]+(-1.15)),"Door angle mismatch")
	set_doors(false,true)
	for node in hinges:assert(is_equal_approx(node.rotation.y,hinges[node]),"Door reset mismatch")
	for i in range(8):set_view(i);assert(camera.position.is_finite(),"Camera invalid")
	set_view(0);var before:=camera.position;toggle_camera_mode();toggle_camera_mode();update_camera();assert(camera.position.distance_to(before)<.0001,"Camera discontinuity")
	toggle_night();assert(world.environment.fog_light_color==Color("30293f"));toggle_night();assert(world.environment.fog_light_color==Color("c9a6aa"))
	print("MODERN_ROOM_CONTROLS_OK Cozy_Potion_Shop ",entries.size()," models; 8 cameras; moving parts; gallery; day/night")
	get_tree().quit()
